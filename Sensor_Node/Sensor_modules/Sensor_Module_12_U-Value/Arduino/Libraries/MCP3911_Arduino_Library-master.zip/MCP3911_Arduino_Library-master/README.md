# Microchip MCP3911 Arduino Library

This is a library for the Microchip MCP3911 analog front end.

Product page: http://www.microchip.com/wwwproducts/en/MCP3911
